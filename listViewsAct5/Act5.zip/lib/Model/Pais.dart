import 'package:flutter/material.dart';

class Pais{
  
  String nombre;
  String bandera;
  String descripcionCorta;
  String descripcionLarga;
  int tag;

  Pais(this.nombre, this.bandera, this.descripcionCorta, this.descripcionLarga, this.tag);
  
}