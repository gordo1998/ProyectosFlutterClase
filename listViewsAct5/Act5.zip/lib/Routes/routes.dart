class Routes{
  Routes._();
  static const login = "/login";
  static const listaPaises =  "/listaPaises";
  static const pais = "/pais";
  static const splash = "/splash";
}