import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:listviews/Model/Fruta.dart';
import 'package:flutter_gen/gen_l10n/app_local.dart';
import 'package:listviews/utils/personal_widgets.dart';
import 'package:listviews/utils/app_settings.dart';

class VistaProducts extends StatefulWidget {
  const VistaProducts({super.key, required this.title});

  

  final String title;

  @override
  State<VistaProducts> createState() => _VistaProducts();
}

class _VistaProducts extends State<VistaProducts> {

  Widget listadoFrutas(BuildContext context){
    final text = AppLocalizations.of(context)!;
    List<Fruta> frutas = [Fruta("${text!.aguacate}", "${text!.precios}: ${NumberFormat.currency().format(29.99)}","assets/aguacates.jpg"), 
                               Fruta("${text!.kiwis}", "${text!.precios}: ", "assets/kiwis.jpg"),
                               Fruta("${text!.manzanas}", "${text!.precios}: ", "assets/manzanas.jpg"), 
                               Fruta("${text!.naranjas}", "${text!.precios}: ", "assets/naranjas.jpg"),
                               Fruta("${text!.peras}", "${text!.precios}: ", "assets/peras.jpg"), 
                               Fruta("${text!.pinyas}", "${text!.precios}: ", "assets/piñas.jpg")
                              ];
    return ListView.builder(
      itemCount: frutas.length,
      itemBuilder: (context, index){
        return CupertinoButton(
          onPressed: (){
            
          },
          child: Card(
            child: ListTile(
              leading: Image.asset("${frutas[index].image}", height: 40, width: 60,),
              title: Text("${frutas[index].name}"),
              subtitle: Text("${frutas[index].descripcion}"),
            ),
          ),
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
        actions: languageSelector(context),
      ),
      body: 
            listadoFrutas(context),
          
      
      
    );
  }
}