class Fruta{
  String name;
  String descripcion;
  String image;
  Fruta(this.name, this.descripcion, this.image);
}