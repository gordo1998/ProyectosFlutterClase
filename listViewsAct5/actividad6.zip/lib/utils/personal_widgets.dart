import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:listviews/main.dart';
import 'package:listviews/utils/app_settings.dart';


/**
 * Widget para mostrar un selector de idioma.
 */
List<Widget> languageSelector(BuildContext context) {
  final appState = context.findAncestorStateOfType<MyApp>();
  return [
    DropdownButton(
      value: appState?.locale,
      icon: const Icon(Icons.language),
      items: const [
        DropdownMenuItem(
          value: Locale('en', 'US'),
          child: Text('English'),
        ),
        DropdownMenuItem(
          value: Locale('es', 'ES'),
          child: Text('Español'),
        ),
      ],
      // Éste callback permite cambiar el idioma de la aplicacion, mediante
      // el método changeLanguage.
      onChanged: (locale) {
        if (locale != null) {
          appState?.changeLanguage(locale);
        }
      },
    )
  ];
}
