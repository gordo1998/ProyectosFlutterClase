import 'package:intl/number_symbols.dart';
import 'package:intl/number_symbols_data.dart';
import 'package:listviews/utils/numberFormatSymbolsExt.dart';
import 'dart:ui' as ui;

/// Internationalization
/// Modificad esta variable para asociar la configuración dependiendo de la zona geográfica.
String defaultLocale = ui.window.locale.languageCode; //Esto me da el codigo de idioma predeterminado
String? defaultLanguage = ui.window.locale.countryCode; //Esto me da la región predeterminada

/// Crear el Locale del idioma por defecto del dispositivo.
String get defaultDeviceLanguage {
  print(defaultLocale);
  String defLocale = defaultLocale;

  if (defaultLanguage != null) {
    defLocale += '_$defaultLanguage'; // <-- P.ej. 'es_ES'
  }

  return defLocale;
}

Map<String, String> get internationalizationSettings {
  print(defaultLocale);

  switch (defaultLocale) { //DefaultLocale lo hemos creado arriba que es el idioma actual
    case 'es_ES':
      numberFormatSymbols['es_ES'] =
          (numberFormatSymbols['es_ES'] as NumberSymbols).copyWith(//esto pertenece a NumberFormarSymbolsExt
        currencySymbol: '€',
      );

      return internES;
    case 'en_US':
      numberFormatSymbols[defaultLocale] =
          (numberFormatSymbols[defaultLocale] as NumberSymbols).copyWith(
        currencySymbol: r'$',
      );
      return internUSA;
    default:
      return internES;
  }
}

/// Internacioanlización España
Map<String, String> get internES => {
      'locale': 'es_ES',
      'currency_symbol': '€',
    };

/// Internacioanlización EEUU
Map<String, String> get internUSA => {
      'locale': 'en_US',
      'currency_symbol': '\$',
    };
