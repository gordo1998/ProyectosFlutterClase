import 'package:flutter/material.dart';


class MyColors{
  final Color grisOscuro = Color.fromARGB(255, 51, 53, 51);
  final Color gris = Color.fromARGB(255, 207, 219, 213);
  final Color grisClaro = Color.fromARGB(255, 232, 237, 223);
  final Color negro = Color.fromARGB(255, 36, 36, 35);
  final Color amarillo = Color.fromARGB(255, 245, 203, 92);

}