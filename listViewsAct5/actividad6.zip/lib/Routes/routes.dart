class Routes{
  Routes._();
  static const login = "/login";
  static const menu = "/menu";
  static const listaPaises =  "/listaPaises";
  static const productos = "/productos";
  static const pais = "/pais";
  static const splash = "/splash";
}